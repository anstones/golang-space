#启动本地tracker
fdfs_trackerd ./conf/tracker.conf restart
#启动本地storage
fdfs_storaged ./conf/storage.conf restart
